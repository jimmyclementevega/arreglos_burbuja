﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        public static void ingresardatos(int[] vector, int tamaño)
        {
            Console.WriteLine("ingrese los valores");
            for (int i = 0; i < tamaño; i++)
            {
                Console.WriteLine("dijite el numero");
                vector[i] = int.Parse(Console.ReadLine());

            }
        }
        static void mostrardatos(int[] vector, int tamaño)
        {
            for (int i = 0; i < tamaño; i++)
            {
                Console.WriteLine("[" + vector[i] + "]" + " ");
            }
            Console.WriteLine();
        }
        public static bool eliminar(int[]vector,ref int tam,int pos)
        {
            if (pos<0||pos>tam)
            {
                return false;//posicion invalida
            }

            for (int i = pos; i <tam-1 ; i++)
            {
                vector[i] = vector[i + 1];

            }
            tam--;
            return true;//se elimino correctamente
        }
        static void Main(string[] args)
        {
            int tamaño, op;
             bool haydatos=false;
            bool eliminado = false;
            
            int[] vector;
            Console.WriteLine("ingrese tamaño");
            tamaño = int.Parse(Console.ReadLine());
            vector = new int[tamaño];
            //menu de op
            do
            {
                Console.WriteLine("\n**menu de opciiones**" +
                                  "\n1.ingresa elementos" +
                                  "\n2.mostrar elementos" +
                                  "\n3.eliminar elementos por posicion" +
                                  "\n4.salir del programa   ");
                Console.WriteLine("seleccione una opcion: ");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1:
                        ingresardatos(vector, tamaño);
                        haydatos = true;
                        break;
                    case 2:
                        if (haydatos)
                        {
                            Console.WriteLine("mostrando el vector");
                            mostrardatos(vector, tamaño);

                        }
                        else
                            Console.WriteLine("debe ingresar elementos");
                        break;
                    case 3:
                        if (haydatos)
                        {
                            Console.WriteLine("ingrese pociion a eliminar");
                            int posicion = int.Parse(Console.ReadLine());
                            eliminado = eliminar(vector, ref tamaño, posicion);
                            if (eliminado)
                            {
                                Console.WriteLine("elemento eliminado");
                                mostrardatos(vector, tamaño);
                            }
                            else
                                Console.WriteLine("pisicion fuera de rango...!!");
                        }
                        else
                            Console.WriteLine("debe ingresar elemento...!!!");
                            break;
                    case 4:
                        Console.WriteLine("saliendo del programa");
                        break;
                       
                    default:
                        Console.WriteLine("ingrese una opcionvalida");
                        break;
                }






            } while (op!=4);
        
        
        }

    }
}
