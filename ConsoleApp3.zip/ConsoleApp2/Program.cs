﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] vector;
            int tamaño;
            Console.WriteLine("ingrese el tamaño del vector: ");
            tamaño = int.Parse(Console.ReadLine());
            vector = new int[tamaño];
            Console.WriteLine("\ningrese los elementos: ");
            for (int i = 0; i < vector.Length; i++)
            {
                Console.WriteLine("digite el valor: " + (i + 1)+ ": ");
                vector[i] = int.Parse(Console.ReadLine());

            }
            //mostrando el vector orginal
            Console.WriteLine("\nmostrando el vector orginal");
            for (int i = 0; i < vector.Length; i++)
            {
                Console.WriteLine("[" + vector[i] + "]" + " ");
            }
            //metodo burbuja
            //primer for recore todo el arreglo de inicio a fin
            int aux;
            for (int i = 0; i < vector.Length-1; i++)
            {
                
                //segundo for 
                for (int j = 0; j < vector.Length-1; j++)
                {
                    if (vector[j] > vector[j+1])
                    {
                        aux = vector[j];
                        vector[j] = vector[j + 1];
                        vector[j + 1] = aux;
                    }
                }
            }
            //mostrar vector
            Console.WriteLine("\nmostrando el vector ordenado");
            for (int i = 0; i < tamaño; i++)
            {
                Console.WriteLine("[" + vector[i] + "]" + " ");

            }
            Console.WriteLine();
        }
    }
}
